# Schrodinger path variable
SCH_PATH = "/home/carlespl/schrodinger2019-2"